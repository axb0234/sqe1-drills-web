export default function History() {
  return (
    <div className="card">
      <div className="card-body">
        <h5 className="card-title">History</h5>
        <p className="text-muted mb-0">Your past drills will appear here.</p>
      </div>
    </div>
  );
}