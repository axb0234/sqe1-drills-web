export default function Reset() {
  return (
    <div className="card">
      <div className="card-body">
        <h5 className="card-title">Reset password</h5>
        <p className="text-muted mb-0">Placeholder — wire this to your identity provider’s reset flow.</p>
      </div>
    </div>
  );
}
